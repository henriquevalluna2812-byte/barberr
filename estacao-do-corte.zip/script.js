// ===== CONFIGURAÇÃO: troque pelo número real (formato 55 + DDD + número) =====
const CONFIG={whatsapp:"5545900000000",msg:"Olá! Gostaria de agendar um horário na Estação do Corte."};
const IMG={hero:"assets/img/foto-1.webp",beard:"assets/img/foto-2.webp",fade:"assets/img/foto-3.webp",tesoura:"assets/img/foto-4.webp"};
const $=(s,c=document)=>[...c.querySelectorAll(s)];
$('img[data-i]').forEach(i=>i.src=IMG[i.dataset.i]);
$('[data-wa]').forEach(a=>{a.href='https://wa.me/'+CONFIG.whatsapp+'?text='+encodeURIComponent(a.dataset.wa||CONFIG.msg);a.target='_blank';a.rel='noopener'});
// menu
const nav=$('#nav')[0],bg=$('.burger')[0];
bg.onclick=()=>{const o=nav.classList.toggle('on');bg.setAttribute('aria-expanded',o)};
nav.onclick=e=>{if(e.target.tagName==='A'){nav.classList.remove('on');bg.setAttribute('aria-expanded',false)}};
const hd=$('header')[0];addEventListener('scroll',()=>hd.classList.toggle('on',scrollY>40),{passive:true});
// aberto agora (horário de Brasília)
const H={2:[9,20],3:[9,20],4:[9,20],5:[9,20],6:[8,18]};
const n=new Date(new Date().toLocaleString('en-US',{timeZone:'America/Sao_Paulo'}));
const d=n.getDay(),h=n.getHours()+n.getMinutes()/60,r=H[d];
$('[data-d="'+d+'"]')[0]?.classList.add('today');
const b=$('#badge')[0],on=r&&h>=r[0]&&h<r[1];
b.classList.toggle('open',!!on);
b.lastChild.textContent=on?'Aberto agora, até '+r[1]+'h':'Fechado agora. Veja os horários abaixo';
// lightbox
const lb=$('#lb')[0];
$('.gi').forEach(g=>g.onclick=()=>{lb.firstElementChild.src=g.firstElementChild.src;lb.classList.add('on')});
lb.onclick=()=>lb.classList.remove('on');
addEventListener('keydown',e=>e.key==='Escape'&&lb.classList.remove('on'));
// ===== GSAP + ScrollTrigger =====
gsap.registerPlugin(ScrollTrigger);
gsap.matchMedia().add('(prefers-reduced-motion: no-preference)',()=>{
  // momento principal: entrada do hero
  gsap.timeline({defaults:{ease:'power3.out'}})
    .from('.hl span',{yPercent:110,duration:1,stagger:.15})
    .from('.fade',{y:24,opacity:0,duration:.8,stagger:.12},'-=.5');
  // parallax do hero
  gsap.to('.hero img',{yPercent:8,ease:'none',scrollTrigger:{trigger:'.hero',start:'top top',end:'bottom top',scrub:true}});
  // trilho de progresso (tema "estação")
  gsap.to('.rail i',{scaleY:1,ease:'none',scrollTrigger:{start:0,end:'max',scrub:.3}});
  // parallax da foto do "Sobre"
  gsap.fromTo('.frame img',{yPercent:-6},{yPercent:6,ease:'none',scrollTrigger:{trigger:'.frame',start:'top bottom',end:'bottom top',scrub:true}});
  gsap.from('.frame',{clipPath:'inset(0 0 100% 0)',duration:1.1,ease:'power3.inOut',scrollTrigger:{trigger:'.frame',start:'top 80%'}});
  // cards, textos e avaliações
  gsap.set('.rv',{opacity:0,y:36});
  ScrollTrigger.batch('.rv',{start:'top 88%',once:true,onEnter:b=>gsap.to(b,{opacity:1,y:0,duration:.7,stagger:.1,ease:'power2.out'})});
  // galeria: revelação por recorte
  gsap.set('.gi',{clipPath:'inset(100% 0 0 0)'});
  ScrollTrigger.batch('.gi',{start:'top 90%',once:true,onEnter:b=>gsap.to(b,{clipPath:'inset(0% 0 0 0)',duration:.9,stagger:.12,ease:'power3.out'})});
  gsap.from('.contact > *',{opacity:0,y:30,duration:.8,stagger:.15,scrollTrigger:{trigger:'.contact',start:'top 80%'}});
});
