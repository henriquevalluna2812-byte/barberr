# Estação do Corte

Site one-page animado (HTML + CSS + JS, GSAP + ScrollTrigger) da barbearia Estação do Corte, Centro de Cascavel-PR.

## Como editar
- Textos, serviços, preços e número do WhatsApp: procure a configuração no início de `script.js` e os textos em `index.html`.
- Fotos: substitua os arquivos em `assets/img/` mantendo os mesmos nomes.

## Publicar
GitHub Pages: Settings > Pages > Branch `main` > pasta `/ (root)`.
